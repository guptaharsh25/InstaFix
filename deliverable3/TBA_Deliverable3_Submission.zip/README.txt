SEG2105 Group Project
Professor: Miguel Garzon

---DELIVERABLE 3 SUBMISSION---

Project Repository URL: https://github.com/guptaharsh25/InstaFix.git
Please note this is a private repository and can only be accessed by the authorized contributors for this repository.

--SERVICE PROVIDER CREDENTIALS--

E-mail: mario@gmail.com
Password: 123456

--TEAM DETAILS--

Team Name: TBA

Team Members:
- Harsh Gupta (Group Leader)
- Bhalachandra Malghan
- Haard Trivedi
- Nischal Sharma
- Nishchal Nepal

--SUBMISSION FILES--

- README.txt
- Deliverable 3 APK
- Word document with UML diagram for deliverable 2 (CircleCI build console screenshot)