SEG2105 Group Project
Professor: Miguel Garzon

---DELIVERABLE 2 SUBMISSION---

Project Repository URL: https://github.com/guptaharsh25/InstaFix.git
Please note this is a private repository and can only be accessed by the authorized contributors for this repository.

--ADMIN CREDENTIALS--

E-mail: admin@admin.gov.ca
Password: helloworld

--TEAM DETAILS--

Team Name: TBA

Team Members:
- Harsh Gupta (Group Leader)
- Bhalachandra Malghan
- Haard Trivedi
- Nischal Sharma
- Nishchal Nepal

--SUBMISSION FILES--

- README.txt
- Deliverable 2 APK
- Word document with UML diagram for deliverable 2 (BONUS CircleCI build console screenshot)