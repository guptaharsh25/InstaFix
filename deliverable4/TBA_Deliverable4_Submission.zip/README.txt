SEG2105 Group Project
Professor: Miguel Garzon

---DELIVERABLE 4 SUBMISSION---

Project Repository URL: https://github.com/guptaharsh25/InstaFix.git
Please note this is a private repository and can only be accessed by the authorized contributors for this repository.

--ADMIN CREDENTIALS--

E-mail: admin@admin.gov.ca
Password: helloworld

--SERVICE PROVIDER CREDENTIALS--

E-mail: mario@gmail.com
Password: 123456

--CLIENT CREDENTIALS--

E-mail: rick@sanchez.com
Password: 123456

--TEAM DETAILS--

Team Name: TBA

Team Members:
- Harsh Gupta (Group Leader)
- Bhalachandra Malghan
- Haard Trivedi
- Nischal Sharma
- Nishchal Nepal

--SUBMISSION FILES--

- README.txt
- Deliverable 4 APK
- Final Report
- Project Folder

--FEATURES WALKTHROUGH--

Search:
- To view all services provided and their service providers, do not change anything and press search.
- To search by service name, type the service name or a substring in the text box and press the search button. For example,
to search for Plumber, type in "plumb" and press the search button.
- To search by rating, move the slider bar around (default at 0) and press the search button.
- To search by availability, click on the calendar icon and select the weekday, start time and end time when the dialog box
appears. Press search in the dialog box after the information has been entered. Press the search icon to search.
NOTE: The searching methods can be mixed and matched to further filter the search.

Booking:
- To book a service, search at least the availability and click on the desired result to book on the list that appears. Click
on the "Book" button when the confirmation dialog is displayed on the screen.