SEG2105 Group Project
Professor: Miguel Garzon

---DELIVERABLE 1 SUBMISSION---

Project Repository URL: https://github.com/guptaharsh25/InstaFix.git
Please note this is a private repository and can only be accessed by the authorized contributors for this repository.

Team Name: TBA

Team Members:
- Harsh Gupta (Group Leader)
- Bhalachandra Malghan
- Haard Trivedi
- Nischal Sharma
- Nishchal Nepal

Files included in this zip folder:
- README.txt
- Deliverable 1 APK
- Word document with UML diagram for deliverable 1.